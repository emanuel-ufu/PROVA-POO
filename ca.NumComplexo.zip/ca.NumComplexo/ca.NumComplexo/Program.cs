﻿using ca.NumComplexo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Nome: Emanuel Simoes Campos
//Matricula: 12311ECP031
namespace ca.NumComplexo
{
    class Program
    {
        static void Main(string[] args)
        {
            NumComplexo z1 = new NumComplexo(1, 1);
            NumComplexo z2 = new NumComplexo(3, -1);

            NumComplexo soma = NumComplexo.Soma(z1, z2);   // Usar o método estático Soma
            NumComplexo produto = NumComplexo.Vezes(z1, z2); // Usar o método estático Vezes

            Console.WriteLine("Soma:");
            soma.ImprimeFormaPolar();

            Console.WriteLine("Produto:");
            produto.ImprimeFormaPolar();
        }
    }
}