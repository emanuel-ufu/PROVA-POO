﻿using ca.NumComplexo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

internal class NumComplexo
{
    private double re;
    private double im;

    // Construtor
    public NumComplexo(double Re, double Im)
    {
        this.re = Re;
        this.im = Im;
    }

    // Getters e setters
    public double Re { get => re; set => re = value; }
    public double Im { get => im; set => im = value; }

    // Adiciona os números complexos
    public static NumComplexo Soma(NumComplexo n1, NumComplexo n2)
    {
        double novo_re = n1.re + n2.re;
        double novo_im = n1.im + n2.im;
        return new NumComplexo(novo_re, novo_im);
    }

    // Multiplica os números complexos
    public static NumComplexo Vezes(NumComplexo n1, NumComplexo n2)
    {
        double novo_re = n1.re * n2.re - n1.im * n2.im;
        double novo_im = n1.re * n2.im + n1.im * n2.re;
        return new NumComplexo(novo_re, novo_im);
    }

    // Calcula o módulo do número complexo
    public double Modulo()
    {
        return Math.Sqrt(re * re + im * im);
    }

    // Calcula o argumento (em graus)
    public double Argumento()
    {
        return Math.Atan2(im, re) * 180 / Math.PI;
    }

    // Imprime a forma polar
    public void ImprimeFormaPolar()
    {
        double modulo = Modulo();
        double argumento = Argumento();
        Console.WriteLine($"{modulo} * (cos({argumento}°) + i * sen({argumento}°))");
    }
}
}