﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

{
    // Atributos da classe
    private string nome_completo;
private string nome_paper;

// Construtor que recebe o nome completo
public NomeProprio(string nomeCompleto)
{
    this.nome_completo = nomeCompleto;
    // Instancia o nome_paper logo após receber o nome_completo
    GerarNomePaper();
}

// Método para gerar o nome_paper baseado no nome_completo
private void GerarNomePaper()
{
    // Divide o nome completo em partes
    string[] partes = nome_completo.Split(' ');

    if (partes.Length == 0)
    {
        nome_paper = string.Empty;
        return;
    }

    // Começa com o primeiro nome
    string primeiroNome = partes[0];

    // Se houver um segundo nome (meio ou inicial), adicione
    string nomeMeio = partes.Length > 1 ? partes[1] : string.Empty;

    // O sobrenome é sempre o último elemento
    string sobrenome = partes.Length > 2 ? partes[partes.Length - 1] : (partes.Length == 2 ? partes[1] : string.Empty);

    // Formata o nome_paper
    nome_paper = $"{primeiroNome} {nomeMeio} {sobrenome}".Trim();
}

// Método para imprimir o nome_paper
public void ImprimirNomePaper()
{
    Console.WriteLine(nome_paper);
}
}